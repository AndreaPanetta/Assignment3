/*package assignment3;

import processing.core.PApplet;
import ddf.minim.*;
import ddf.minim.signals.*;
import ddf.minim.analysis.*;
import ddf.minim.effects.*;

import java.util.*;

public class Songs 
{
	ArrayList<MenuSong> songs = new ArrayList<MenuSong>();

	//SONGS ARRAY LISTS 
	public void songSetup()
	{
		songs.add(new MenuSong(Assignment3.applet.minim.loadFile("Culture Beat           Mr. Vain.mp3")));
		songs.add(new MenuSong(Assignment3.applet.minim.loadFile("Sandstorm.mp3")));
		songs.add(new MenuSong(Assignment3.applet.minim.loadFile("Technotronic - Pump Up The Jam.mp3")));
		songs.add(new MenuSong(Assignment3.applet.minim.loadFile("Gigi D'Agostino - L'Amour Toujours ( Official Video ).mp3")));
	  	songs.add(new MenuSong(Assignment3.applet.minim.loadFile("Daft Punk - Technologic.mp3")));
	  	songs.add(new MenuSong(Assignment3.applet.minim.loadFile("Warriors Dance - The Prodigy.mp3")));
	}

	public class MenuSong
	{
	  AudioPlayer songs;

	  MenuSong(AudioPlayer songs)
	  {
	    this.songs = songs;
	  }
	}
}

*/