package assignment3;

import processing.core.PApplet;
import processing.core.PVector;
import processing.data.XML;
import ddf.minim.*;
import ddf.minim.signals.*;
import ddf.minim.analysis.*;
import ddf.minim.effects.*;

import java.awt.Color;
import java.util.*;

public class Player
{
  PVector pos;
  char up;
  char down;
  char left;
  char right;
  char start;
  char button1;
  char button2;
  int index;
  Color Colour;
    
  Player()
  {
	  Assignment3.applet.pos = new PVector(Assignment3.applet.width / 2, Assignment3.applet.height / 2);
  }
  
  Player(int index, Color Colour, char up, char down, char left, char right, char start, char button1, char button2)
  {
	  this();
	  this.index = index;
	  this.Colour = Colour;
	  this.up = up;
	  this.down = down;
	  this.left = left;
	  this.right = right;
	this.start = start;
    this.button1 = button1;
    this.button2 = button2;
  }
  
  Player(int index, Color Colour, XML xml)
  {
    this(index
        , Colour
        , Assignment3.applet.buttonNameToKey(xml, "up")
        , Assignment3.applet.buttonNameToKey(xml, "down")
        , Assignment3.applet.buttonNameToKey(xml, "left")
        , Assignment3.applet.buttonNameToKey(xml, "right")
        , Assignment3.applet.buttonNameToKey(xml, "start")
        , Assignment3.applet.buttonNameToKey(xml, "button1")
        , Assignment3.applet.buttonNameToKey(xml, "button2")
        );
  }
  
  public boolean collisionCheck2(BlueCir b1)
  {
    if (pos.x - Assignment3.applet.playerSize < b1.BlueCirx + 20 && pos.x + Assignment3.applet.playerSize > b1.BlueCirx && pos.y - Assignment3.applet.playerSize < b1.BlueCiry + 20 && pos.y + Assignment3.applet.playerSize > b1.BlueCiry)
    {
      return true;
    }
    return false;
  }
  
   //CHECKING COLLISION OF PLAYER WITH HORIZONTAL CIRCLE
  public boolean collisionCheck3(BlueCir bc)
  {
    if (Assignment3.applet.BlueCirx1>pos.x && Assignment3.applet.BlueCirx1 < pos.x+Assignment3.applet.playerSize && Assignment3.applet.BlueCiry1 > pos.y && Assignment3.applet.BlueCiry1 < pos.y+Assignment3.applet.playerSize)
    {
      return true;
    }
    return false;
  }
  
  //CHECKING COLLISION OF PLAYER WITH VERTICAL SQAURES
  public boolean collisionCheck2(Platforms p1)
  {
    if (pos.x - Assignment3.applet.playerSize < Assignment3.applet.platX + 20 && pos.x + Assignment3.applet.playerSize > Assignment3.applet.platX && pos.y - Assignment3.applet.playerSize < Assignment3.applet.platY + 20 && pos.y + Assignment3.applet.playerSize > Assignment3.applet.platY)
    {
    	return true;
    }
    return false;
  }
  
  
  public void update()
  {
    
    if(Assignment3.applet.check > 100)
    {
    	Assignment3.applet.playerSpeed = 5;
    }
    
    if(Assignment3.applet.check > 100)
    {
    	Assignment3.applet.circleSize = 20;
    }
    
    if(Assignment3.applet.check > 150)
    {
    	Assignment3.applet.platformSizeX = 50;
    	Assignment3.applet.platformSizeY = 30;
    }
    
    
      
    if (Assignment3.applet.checkKey(up))
    {
    	pos.y -= Assignment3.applet.playerSpeed;
    }
    if (Assignment3.applet.checkKey(down))
    {
    	pos.y += Assignment3.applet.playerSpeed;
    }
    if (Assignment3.applet.checkKey(left))
    {
    	pos.x -= Assignment3.applet.playerSpeed;
    }    
    if (Assignment3.applet.checkKey(right))
    {
    	pos.x += Assignment3.applet.playerSpeed;
    }
    if (Assignment3.applet.checkKey(start))
    {
    	Assignment3.applet.println("Player " + index + " start");
    }
    if (Assignment3.applet.checkKey(button1))
    {
    	Assignment3.applet.println("Player " + index + " button 1");
    }
    if (Assignment3.applet.checkKey(button2))
    {
    	Assignment3.applet.println("Player " + index + " butt2");
    }    
  }
  
  public void display()
  {    
	  //Assignment3.applet.stroke(Assignment3.applet.Colour);
	  //Assignment3.applet.fill(Assignment3.applet.Colour);    
	  Assignment3.applet.rect(pos.x,pos.y, 50, 50);
  }  
}