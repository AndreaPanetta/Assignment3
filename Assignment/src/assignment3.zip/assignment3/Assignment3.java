package assignment3;

import java.awt.Color;
import java.util.ArrayList;

import processing.core.PApplet;
import processing.data.XML;
import ddf.minim.AudioInput;
import ddf.minim.AudioPlayer;
import ddf.minim.Minim;

  


public class Assignment3 extends PApplet {
	
public static Assignment3 applet;
BlueCir bc1,bc2;
Platforms p1;

float playerSpeed= 3;
int check=0;
int lives=500;


float R=125;
float centerR=125;
float a=PI/2;
float a1=PI;
float a2=3*PI/2;
float pathR=125;
float pathG=125;
float G=125;
float centerG=125;
float pathB=125;
float B=125;
float centerB=125;


ArrayList<Player> players = new ArrayList<Player>();
boolean[] keys = new boolean[526];

int BPcircles;

int i;

float  platX = 0;
  float  platY = 0;

int playerSize =50;

int circleSize =40;

int platformSizeX =30;
int platformSizeY =10;

int blueCIR = 2;
BlueCir[] BlueCirArr= new BlueCir[blueCIR];
BlueCir[] BlueCirArr2= new BlueCir[blueCIR];
//BLUE CIRCLE VARIABLES
float BlueCirx1 = random(width, 2*width+60);
float BlueCiry1= random(height);

int platforms=4;
Platforms[] Platform = new Platforms[platforms];

int bSpeeds =10;

boolean devMode = true;
public boolean sketchFullScreen() 
{
  return ! devMode;
}


Minim minim;
AudioPlayer player;
AudioInput input; 

public Object pos;
private Color Colour;

public void setup()
{
	applet = this;
  //SIZING OF SCREEN
  if (devMode)
  {
    size(800, 600);
  } else
  {
    size(displayWidth, displayHeight);
  }
  setUpPlayerControllers();
  
  //BLUE CIRCLE FROM BOTTOM
  for (int j = 0; j < BlueCirArr.length; j++) 
  {
    BlueCirArr[j] = new BlueCir(); // Create each object
    bc1 = new BlueCir();
  }
  
  //BLUE CIRCLE FROM BOTTOM
  for (int j = 0; j < Platform.length; j++) 
  {
    Platform[j] = new Platforms(); // Create each object
    p1 = new Platforms();
  }
  
  for (int j = 0; j < BlueCirArr2.length; j++) 
  {
    BlueCirArr2[j] = new BlueCir(); // Create each object
    bc2 = new BlueCir();
  }
  
  //MUSIC
 /* minim = new Minim(this);
  Assignment3.applet.songsSetup();
  int i = (int)random(0, Assignment3.applet.songs.size());
  player= Assignment3.applet.songs.get(i).songs;
  player.play();
  
  */
}


public void draw()
{
  
  background(pathR,pathG,pathB);
  pathR=centerR+R*sin(a);
  a=(float)(a+.03);
   
  pathG=centerG+G*sin(a1);
  a1=(float)(a1+.03);
   
  pathB=centerB+B*sin(a2);
  a2=(float)(a2+.03);
  for(Player player:players)
  {
    player.update();
    player.display();
  }
  
  Player p4 = players.get(0); // DECTECTING COLLISION WITH THE BLUE SQUARE 

  for (int i = 0; i < players.size (); i++)
  {
    BlueCir b1 = BlueCirArr[i];

    if (p4.collisionCheck2(b1))
    {
      
       check++;
    }
  }
  
  Player p2 = players.get(0); // DECTECTING COLLISION WITH THE BLUE SQUARE 

  
 
 
  Player p7 = players.get(0); // DETECTING IT AGAINST THE BLUE PLAYER 
   textSize(50);
  fill(0);
  text("SCORE: ", 420, 50);
  text(check, 700, 50);
  textSize(50);
  fill(0);
  text("LIVES: ", 10, 50);
  text(lives, 200, 50);

  for (int i = 0; i < players.size (); i++)
  {
    BlueCir bc = BlueCirArr2[i];

    if (p7.collisionCheck3(bc))
    {
      check++;
    }
  }
  
  Player p3 = players.get(0); // DECTECTING COLLISION WITH THE BLUE SQUARE 

  for (int i = 0; i < players.size (); i++)
  {
    Platforms p = Platform[i];

    if (p3.collisionCheck2(p1))
    {

      lives--;
    }
  }
  
 /* if (!player.isPlaying() )
  {
    int i = (int) random(0, songs.size());
    player= songs.get(i).songs;
    player.play();
  }
  
  */
  
  for (int j = 0; j < BlueCirArr.length; j++) 
  {
    BlueCirArr[j].falldown();
  }
  
  for (int j = 0; j < BlueCirArr.length; j++) 
  {
    BlueCirArr[j].fallacross();
  }
  
  for (int j = 0; j < Platform.length; j++) 
  {
    Platform[j].falldown();
  }
  
  
}

public void keyPressed()
{
  keys[keyCode] = true;
}

public void keyReleased()
{
  keys[keyCode] = false;
}

boolean checkKey(char theKey)
{
  return keys[Character.toUpperCase(theKey)];
}

public char buttonNameToKey(XML xml, String buttonName)
{
  String value =  xml.getChild(buttonName).getContent();
  if ("LEFT".equalsIgnoreCase(value))
  {
    return LEFT;
  }
  if ("RIGHT".equalsIgnoreCase(value))
  {
    return RIGHT;
  }
  if ("UP".equalsIgnoreCase(value))
  {
    return UP;
  }
  if ("DOWN".equalsIgnoreCase(value))
  {
    return DOWN;
  }
  //.. Others to follow
  return value.charAt(0);  
}

public void setUpPlayerControllers()
{
  XML xml = loadXML("arcade.xml");
  XML[] children = xml.getChildren("player");
  int gap = width / (children.length + 1);
  

    XML playerXML = children[0];
    Player p = new Player(0,Assignment3.applet.Colour, playerXML);
    int x = (1) * gap;
    p.pos.x = x;
    p.pos.y = 300;
   players.add(p);         
  
}
}